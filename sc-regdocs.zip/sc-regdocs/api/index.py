"""Read-only JSON API over data/catalogue.json (built by the collector, committed to git).

Vercel serves this FastAPI `app` from api/index.py (all routes rewritten in vercel.json).
"""
from __future__ import annotations

import base64
import json
from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query

CATALOGUE = Path(__file__).resolve().parent.parent / "data" / "catalogue.json"
DATE_FIELDS = {"sort_date", "revised", "updated", "issued", "effective", "applicable_until", "expired"}

app = FastAPI(
    title="SC Malaysia regulatory documents (unofficial)",
    description="Metadata index built from public pages on sc.com.my. Not an SC product; "
                "always confirm against the official source linked in each record.",
    version="0.1.0",
)


@lru_cache(maxsize=1)
def _cat() -> dict:
    if not CATALOGUE.exists():
        return {"generated_at": None, "documents": []}
    return json.loads(CATALOGUE.read_text(encoding="utf-8"))


def _public(d: dict) -> dict:
    return d


def _date_of(d: dict, field: str):
    return d.get("sort_date") if field == "sort_date" else d.get("dates", {}).get(field)


def _encode(offset: int) -> str:
    return base64.urlsafe_b64encode(str(offset).encode()).decode()


def _decode(cursor: str | None) -> int:
    if not cursor:
        return 0
    try:
        return max(0, int(base64.urlsafe_b64decode(cursor.encode()).decode()))
    except Exception:
        raise HTTPException(400, "invalid cursor")


@app.get("/health")
def health():
    c = _cat()
    return {"status": "ok", "catalogue_generated_at": c.get("generated_at"), "documents": len(c["documents"])}


@app.get("/v1/documents")
def list_documents(
    q: str | None = Query(None, description="case-insensitive title substring"),
    category: str | None = None,
    topic: str | None = None,
    document_type: str | None = Query(None, description="main | amendment_summary | faq"),
    family: str | None = Query(None, description="document_family_id"),
    year: int | None = Query(None, description="year of the record's primary date (revised > issued > effective)"),
    date_field: str = Query("sort_date", description=f"one of {sorted(DATE_FIELDS)}"),
    date_from: str | None = Query(None, pattern=r"^\d{4}-\d{2}-\d{2}$"),
    date_to: str | None = Query(None, pattern=r"^\d{4}-\d{2}-\d{2}$"),
    include_removed: bool = False,
    limit: int = Query(50, ge=1, le=200),
    cursor: str | None = None,
):
    if date_field not in DATE_FIELDS:
        raise HTTPException(400, f"date_field must be one of {sorted(DATE_FIELDS)}")
    rows = _cat()["documents"]
    ql = q.lower() if q else None

    def ok(d: dict) -> bool:
        if not include_removed and not d["collection"].get("still_listed", True):
            return False
        if ql and ql not in d["title"].lower():
            return False
        if category and d.get("category") != category:
            return False
        if topic and d.get("topic") != topic:
            return False
        if document_type and d["document_type"] != document_type:
            return False
        if family and d["document_family_id"] != family:
            return False
        if year and d.get("year") != year:
            return False
        if date_from or date_to:
            v = _date_of(d, date_field)
            if not v or (date_from and v < date_from) or (date_to and v > date_to):
                return False
        return True

    hits = [d for d in rows if ok(d)]
    start = _decode(cursor)
    page = hits[start:start + limit]
    nxt = _encode(start + limit) if start + limit < len(hits) else None
    return {"data": [_public(d) for d in page],
            "meta": {"total_matches": len(hits), "returned_count": len(page), "next_cursor": nxt,
                     "catalogue_generated_at": _cat().get("generated_at")}}


@app.get("/v1/documents/{document_id}")
def get_document(document_id: str):
    for d in _cat()["documents"]:
        if d["source_document_id"] == document_id.lower():
            related = [r["source_document_id"] for r in _cat()["documents"]
                       if r.get("parent_document_id") == d["source_document_id"]]
            return {"data": d, "related_document_ids": related}
    raise HTTPException(404, "document not found")


@app.get("/v1/families")
def families(category: str | None = None):
    fams: dict[str, dict] = {}
    for d in _cat()["documents"]:
        if d["document_type"] != "main" or (category and d.get("category") != category):
            continue
        f = fams.setdefault(d["document_family_id"], {"document_family_id": d["document_family_id"],
                                                      "title": d["title"], "category": d.get("category"),
                                                      "topic": d.get("topic"), "versions": 0,
                                                      "earliest": None, "latest": None})
        f["versions"] += 1
        sd = d.get("sort_date")
        if sd:
            f["earliest"] = min(filter(None, [f["earliest"], sd]))
            f["latest"] = max(filter(None, [f["latest"], sd]))
    return {"data": sorted(fams.values(), key=lambda f: (f["category"] or "", f["title"]))}


@app.get("/v1/stats")
def stats():
    docs = _cat()["documents"]
    status: dict[str, int] = {}
    checks: dict[str, int] = {}
    for d in docs:
        s = d["collection"]["download_status"].split(":")[0]
        status[s] = status.get(s, 0) + 1
        k = str(d["collection"].get("date_check"))
        checks[k] = checks.get(k, 0) + 1
    years = sorted({d["year"] for d in docs if d.get("year")})
    return {"documents": len(docs), "year_range": [years[0], years[-1]] if years else None,
            "download_status": status, "date_check": checks,
            "downloaded_and_hashed": sum(1 for d in docs if d["collection"].get("file_sha256")),
            "catalogue_generated_at": _cat().get("generated_at"),
            "note": "Coverage is limited to the section pages crawled; see README for scope."}
